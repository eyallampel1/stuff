/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define HTDU21D_ADDRESS 0x40  //Unshifted 7-bit I2C address for the sensor

#define TRIGGER_TEMP_MEASURE_HOLD  0xE3
#define TRIGGER_HUMD_MEASURE_HOLD  0xE5
#define TRIGGER_TEMP_MEASURE_NOHOLD  0xF3
#define TRIGGER_HUMD_MEASURE_NOHOLD  0xF5
#define WRITE_USER_REG  0xE6
#define READ_USER_REG  0xE7
#define SOFT_RESET  0xFE

#include <project.h>
#include <stdlib.h>
#include <stdio.h>
int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
I2C_1_Start();
UART_1_Start();
UART_1_PutString("lampel start of program \n\r");
//SW_Tx_UART_1_Start();
uint8 DATAtoI2C_one[1]={0xf3};
//uint8 DATAtoI2C_2[1]={0xf3};
//uint8 DATAtoI2C_3[1]={0xf3};
//uint8 DATAtoI2C_4[1]={0xf3};
uint8 readI2Cdata[2]={0};

//I2C_1_I2CMasterWriteBuf(HTDU21D_ADDRESS,(uint8 *) DATAtoI2C_one,1,I2C_1_I2C_MODE_COMPLETE_XFER);
//I2C_1_I2CMasterWriteBuf(HTDU21D_ADDRESS,DATAtoI2C_one,1,I2C_1_I2C_MODE_COMPLETE_XFER);
//I2C_1_I2CMasterWriteBuf(HTDU21D_ADDRESS,DATAtoI2C_one,1,I2C_1_I2C_MODE_COMPLETE_XFER);
//I2C_1_I2CMasterWriteBuf(HTDU21D_ADDRESS,DATAtoI2C_one,1,I2C_1_I2C_MODE_COMPLETE_XFER);

/* Transfer complete. Check Master status to make sure that transfer
completed without errors. */

//char stringtouart[5];
//CyDelay(1000);
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        I2C_1_I2CMasterWriteBuf(HTDU21D_ADDRESS,(uint8 *) DATAtoI2C_one,1,I2C_1_I2C_MODE_COMPLETE_XFER);
        while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT))
{
    break;
}
        CyDelay(1000);
      I2C_1_I2CMasterReadBuf(HTDU21D_ADDRESS,readI2Cdata,3,I2C_1_I2C_MODE_COMPLETE_XFER);
   // itoa(readI2Cdata[0] && readI2Cdata[1],stringtouart,10);  
char Buffer[20];
int16 IntTemp = (int16)readI2Cdata[0] << 8 | readI2Cdata[1];
float celciosTemp=(float)-46.85+175.72*((float)IntTemp)/65536;
sprintf(Buffer,"temp is: %f\n\r",celciosTemp);

UART_1_PutString(Buffer);
    
    
    CyDelay(1000);
      //  I2C_1_I2CMasterSendStop();
  //   SW_Tx_UART_1_PutHexByte(readI2Cdata[0]);
  	//float tempTemperature = rawTemperature / (float)65536; //2^16 = 65536
	//float realTemperature = (float)(-46.85 + (175.72 * tempTemperature)); //From page 14
        
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
