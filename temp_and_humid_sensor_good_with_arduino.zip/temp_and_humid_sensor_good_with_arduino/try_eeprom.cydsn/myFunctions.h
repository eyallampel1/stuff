/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
/* [] END OF FILE */
uint8 ConvertFromAsciiToUint8(char userInput)
{
    uint8 UINT8DataFromUser;
    switch (userInput)
    {
    case 'f' :
    UINT8DataFromUser=0xf;
     break;
        case 'e' :
    UINT8DataFromUser=0xe;
     break;
            case 'd' :
    UINT8DataFromUser=0xd;
     break;
            case 'c' :
    UINT8DataFromUser=0xc;
     break;
            case 'b' :
    UINT8DataFromUser=0xb;
     break;
            case 'a' :
    UINT8DataFromUser=0xa;
     break;
                  case '9' :
    UINT8DataFromUser=0x9;
     break;  
                          case '8' :
    UINT8DataFromUser=0x8;
     break;  
                          case '7' :
    UINT8DataFromUser=0x7;
     break;  
                          case '6' :
    UINT8DataFromUser=0x6;
     break;  
                          case '5' :
    UINT8DataFromUser=0x5;
     break;  
                          case '4' :
    UINT8DataFromUser=0x4;
     break;  
                          case '3' :
    UINT8DataFromUser=0x3;
     break;  
                          case '2' :
    UINT8DataFromUser=0x2;
     break;  
                          case '1' :
    UINT8DataFromUser=0x1;
     break;  
                          case '0' :
    UINT8DataFromUser=0x0;
     break;  
        
    }
    
    return UINT8DataFromUser;
}