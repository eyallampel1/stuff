/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define eepromDeviceAddres 0x50
#include <project.h>
char userInput;
int rxIndex=0;
char twoBytesFromUserUart[4]={'0'};
char dataFromUserUart[2]={'0'};
CY_ISR(rxInterrupt){
    
    userInput=UART_1_GetChar();
  rxIndex+=1;
    if(rxIndex==9){
    rxIndex=0;
    }
    
}

uint8 readDataFromUser()
{
        while (rxIndex!=4){
   // UART_1_GetChar();
        
    if(rxIndex==1){
    rxIndex+=1;
        dataFromUserUart[0]=userInput;
        }
      if(rxIndex==3){
    rxIndex+=1;
        dataFromUserUart[1]=userInput;
        }
     
    
    }
    rxIndex=0;
   return 1;
    
}

uint8 readAdressFromUser( )
{
    
    while (rxIndex!=9){
   // UART_1_GetChar();
        
    if(rxIndex==2){
    rxIndex+=1;
        twoBytesFromUserUart[0]=userInput;
        }
      if(rxIndex==4){
    rxIndex+=1;
        twoBytesFromUserUart[1]=userInput;
        }
      if(rxIndex==6){
    rxIndex+=1;
        twoBytesFromUserUart[2]=userInput;
        }
      if(rxIndex==8){
   rxIndex+=1;
        twoBytesFromUserUart[3]=userInput;
         UART_1_PutString(" --done-- \n\r");
        }
    
    }
     rxIndex=0;
   return 1;
}

void writeToEEprom(uint8 deviceAdress,uint8 highEEPROMadress,uint8 lowEEPROMadress,uint8 dataToWrite)
{
  uint8 eepromMemoryADRESSStoWRITETO[3];
eepromMemoryADRESSStoWRITETO[0]=highEEPROMadress;
eepromMemoryADRESSStoWRITETO[1]=lowEEPROMadress;
eepromMemoryADRESSStoWRITETO[2]=dataToWrite;//write to adress 00aa data dd

  I2C_1_I2CMasterWriteBuf(deviceAdress,(uint8 *)eepromMemoryADRESSStoWRITETO,3,I2C_1_I2C_MODE_COMPLETE_XFER);

        while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT))
{
    break;
}
//=========//
//I2C_1_I2CMasterSendStop();
        CyDelay(1000);     
}

uint8  ReadFromEEprom(uint8 deviceAdress,uint8 highEEPROMadress,uint8 lowEEPROMadress)
{
 uint8 eepromMemoryADRESSStoWRITETO[3];
eepromMemoryADRESSStoWRITETO[0]=highEEPROMadress;
eepromMemoryADRESSStoWRITETO[1]=lowEEPROMadress;///adress 00aa   
uint8 readDatafromeeprom_raw[1]={0x00};   
    uint8 readDatafromeeprom=0x00;

I2C_1_I2CMasterWriteBuf(deviceAdress,(uint8 *)eepromMemoryADRESSStoWRITETO,2,I2C_1_I2C_MODE_COMPLETE_XFER); 
        while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT))
{
    break;
}
CyDelay(500);

I2C_1_I2CMasterReadBuf(deviceAdress,readDatafromeeprom_raw,1,I2C_1_I2C_MODE_COMPLETE_XFER);
       while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_RD_CMPLT))
{
    break;
}
CyDelay(1000); 
readDatafromeeprom=readDatafromeeprom_raw[0];
return readDatafromeeprom;
}

int main()
{
   
    CyGlobalIntEnable; /* Enable global interrupts. */
 isr_1_StartEx(rxInterrupt);
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
I2C_1_Start();
UART_1_Start();
CyDelay(1000);
UART_1_PutString("welcom to lampel psoc\n\r");
UART_1_PutString("Do you Want to read or write to FRAM ? (w/r) \n\r");


userInput='4';

while (userInput!='0'){
   // userInput=UART_1_GetChar();
if (userInput=='w')
{
    UART_1_PutString("what adress do you want to write to ? (Ex:0x00f1)\n\r");
    readAdressFromUser();
    UART_1_PutString(" what data do you want to write ? (Ex:0xff) \n\r");
    readDataFromUser();
    
    writeToEEprom(eepromDeviceAddres,0x00,0x33,0xee);
    userInput='0';//stop and exit the loop user finshed write to eeprom
}

if (userInput=='r')
{
uint8 readDatafromeeprom[1]={0x00};
readDatafromeeprom[0]=ReadFromEEprom(eepromDeviceAddres,0x01,0x33);
    
}


}

    
        
    for(;;)
    {
      CyDelay(1000);    /* Place your application code here. */
    }
}

/* [] END OF FILE */
