/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define eepromDeviceAddres 0x50
#include <project.h>
#include <myFunctions.h>
char userInput;
int rxIndex=0 , clearindex=1;
uint8 twoBytesFromUserUart[4]={0x00};
char dataFromUserUart[2]={'0'};
CY_ISR(rxInterrupt){
//    uint8 source;
  //  source = UART_1_GetRxInterruptSourceMasked();
    //UART_1_ClearRxInterruptSource(rxInterrupt);
    
    //UART_1_uartClearRxBuffer(rxInterrupt);
   // UART_1_UartClearRxInterruptSource();
   UART_1_ClearRxInterruptSource(rxInterrupt);
//UART_1_ClearMasterInterruptSource(rxInterrupt);
if (clearindex==1){   
clearindex+=1;
    userInput=UART_1_UartGetChar();
  rxIndex+=1;
    if(rxIndex==9){
    rxIndex=0;
    }
}
else
{
    clearindex=1;
}

}




uint8 readDataFromUser()
{
        while (rxIndex!=4){
   // UART_1_GetChar();
        
    if(rxIndex==1){
    rxIndex+=1;
        dataFromUserUart[0]=ConvertFromAsciiToUint8(userInput);
        }
      if(rxIndex==3){
    rxIndex+=1;
        dataFromUserUart[1]=ConvertFromAsciiToUint8(userInput);
        }
     
    
    }
    rxIndex=0;
   return 1;
    
}

uint8 readAdressFromUser( )
{
    
    while (rxIndex!=9){
   // UART_1_GetChar();
        
    if(rxIndex==2){
    rxIndex+=1;
         
        twoBytesFromUserUart[0]=ConvertFromAsciiToUint8(userInput);
        }
      if(rxIndex==4){
    rxIndex+=1;
        twoBytesFromUserUart[1]=ConvertFromAsciiToUint8(userInput);
        }
      if(rxIndex==6){
    rxIndex+=1;
        twoBytesFromUserUart[2]=ConvertFromAsciiToUint8(userInput);
        }
      if(rxIndex==8){
   rxIndex+=1;
        twoBytesFromUserUart[3]=ConvertFromAsciiToUint8(userInput);
         UART_1_UartPutString(" --done-- \n\r");
        }
    
    }
     rxIndex=0;
   return 1;
}

void writeToEEprom(uint8 deviceAdress,uint8 highEEPROMadress,uint8 lowEEPROMadress,uint8 dataToWrite)
{
  uint8 eepromMemoryADRESSStoWRITETO[3];
eepromMemoryADRESSStoWRITETO[0]=highEEPROMadress;
eepromMemoryADRESSStoWRITETO[1]=lowEEPROMadress;
eepromMemoryADRESSStoWRITETO[2]=dataToWrite;//write to adress 00aa data dd

 // I2C_1_I2CMasterWriteBuf(deviceAdress,(uint8 *)eepromMemoryADRESSStoWRITETO,3,I2C_1_I2C_MODE_COMPLETE_XFER);

      //  while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT))
//{
 //   break;
//}
//=========//
//I2C_1_I2CMasterSendStop();
        CyDelay(1000);     
}

uint8  ReadFromEEprom(uint8 deviceAdress,uint8 highEEPROMadress,uint8 lowEEPROMadress)
{
 uint8 eepromMemoryADRESSStoWRITETO[3];
eepromMemoryADRESSStoWRITETO[0]=highEEPROMadress;
eepromMemoryADRESSStoWRITETO[1]=lowEEPROMadress;///adress 00aa   
uint8 readDatafromeeprom_raw[1]={0x00};   
    uint8 readDatafromeeprom=0x00;

//I2C_1_I2CMasterWriteBuf(deviceAdress,(uint8 *)eepromMemoryADRESSStoWRITETO,2,I2C_1_I2C_MODE_COMPLETE_XFER); 
      //  while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT))
//{
 //   break;
//}
CyDelay(500);

//I2C_1_I2CMasterReadBuf(deviceAdress,readDatafromeeprom_raw,1,I2C_1_I2C_MODE_COMPLETE_XFER);
     //  while( (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_RD_CMPLT))
//{
 //   break;
//}
CyDelay(1000); 
readDatafromeeprom=readDatafromeeprom_raw[0];
return readDatafromeeprom;
}

int main()
{
 uint8 HighEEpromAdress,LOWEEpromAdress,dataToWriteToEEprom; 
uint8 first={0x0d};
 uint8 sec={0x0f};
uint8 combain,firstshift;
firstshift=first << 4 | sec ;// moves 4 binary bits to the left or 1 hex to the left 0x0d--->0xd0 ,0xd0 |=+0x0f -->0xdf ;

    CyGlobalIntEnable; /* Enable global interrupts. */
 isr_1_StartEx(rxInterrupt);
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
//I2C_1_Start();
UART_1_Start();
CyDelay(1000);
UART_1_UartPutString("welcom to lampel psoc\n\r");
UART_1_UartPutString("Do you Want to read or write to FRAM ? (w/r) \n\r");


userInput='4';

while (userInput!='0'){
   // userInput=UART_1_GetChar();
if (userInput=='w')
{
    UART_1_UartPutString("what adress do you want to write to ? (Ex:0x00f1)\n\r");
    readAdressFromUser();
    UART_1_UartPutString(" what data do you want to write ? (Ex:0xff) \n\r");
    readDataFromUser();
    
    HighEEpromAdress=twoBytesFromUserUart[0] << 4 | twoBytesFromUserUart[1];
    LOWEEpromAdress=twoBytesFromUserUart[2] << 4 | twoBytesFromUserUart[3];
    dataToWriteToEEprom=dataFromUserUart[0] << 4 | dataFromUserUart[1];
    
    writeToEEprom(eepromDeviceAddres,HighEEpromAdress,LOWEEpromAdress,dataToWriteToEEprom);
    userInput='0';//stop and exit the loop user finshed write to eeprom
}

if (userInput=='r')
{
uint8 readDatafromeeprom[1]={0x00};
readDatafromeeprom[0]=ReadFromEEprom(eepromDeviceAddres,0x01,0x33);
    
}


}

    
        
    for(;;)
    {
      CyDelay(1000);    /* Place your application code here. */
    }
}

/* [] END OF FILE */
